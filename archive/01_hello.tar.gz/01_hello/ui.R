# ui -----------------------------

shinyUI(fluidPage(
	titlePanel("たいとる"),
	mainPanel(),
	sidebarPanel()
 )
)
